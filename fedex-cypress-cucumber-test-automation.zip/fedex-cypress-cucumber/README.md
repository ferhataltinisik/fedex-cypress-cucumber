# Star Wars search page cypress cucumbe e2e-testing
This framework is an assessment for a QA role sent by FedEx. It is designed based on Cucumber BDD approach and Page Object Model pattern and uses the Cypress test framework to test a single web page application - Star Wars Search. The web application is for Star Wars enthusiasts who want to find information about their favorite characters and planets.

## Overview of the Cypress Test Framework
The Cypress test framework is a JavaScript end-to-end testing tool that is used for testing web applications. It supports various types of tests such as unit, integration, and end-to-end tests. Cypress provides a simple and powerful API that allows developers to write tests in JavaScript. Cypress also comes with a built-in test runner, which allows developers to run tests, debug, and see the results.



## Pre-requisites

1. Node JS
2. Cypress >= version 10


##  Install the project

Install project dependencies with: `npm install`

##  Multiple cucumber html reporter
For multiple cucumber html report please visit : https://github.com/WasiqB/multiple-cucumber-html-reporter


## Run the demo:

1. Standard Execution: npm run cypress:execution
2. Allure Report: `npm run cypress:execution-allure`


##  Test Structure
The framework is based on the Cucumber BDD and Page Object Model design pattern. This design pattern allows the separation of page objects and test cases, making tests more maintainable and less brittle.

##  Test Results
The test report is generated under report in cucumber-report.html. To generate test report you can use `npm run cypress:execution-allure`. In case of any test failures, the report shows the details of the failure, along with a screenshot. The cypress-mochawesome-reporter generates a beautiful and interactive HTML report, which makes it easy to understand the test results.

![Test Report Screenshot](cypress/fixtures/test-report.png)

##  Conclusion
This Cypress test framework is designed for testing the Star Wars Search web application, BDD approach and Page Object Model pattern. The framework provides a simple, powerful, and maintainable way to write end-to-end tests. With its built-in test runner and the cypress-mochawesome-reporter, the framework generates beautiful HTML reports that make it easy to understand the test results.

## Important Note
Before running the project, please ensure that you have downloaded and installed the Star Wars Search Angular app from the same GitHub repository. To do so, `run npm install` and `ng serve` after downloading the app. Additionally, I have made some changes to the Star Wars Search application to make it easier to find the web elements in the application using the Cypress test framework. Therefore, it is crucial to download the modified version from the Git repository.