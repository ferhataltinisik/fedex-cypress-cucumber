const report = require("multiple-cucumber-html-reporter");
report.generate({
  jsonDir: "jsonlogs", // ** Path of .json file **//
  reportPath: "./reports/cucumber-htmlreport.html",
  metadata: {
    browser: {
      name: "chrome",
      version: "112",
    },
    device: "Local test machine",
    platform: {
      name: "Mac",
      version: "12.5",
    },
  },
  customData: {
    title: "Start Wars search page report",
    data: [
      { label: "Project", value: "Start Wars project" }
    ],
  },
});
