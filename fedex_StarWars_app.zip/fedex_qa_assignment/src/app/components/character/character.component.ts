import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-character',
  templateUrl: './character.component.html',
})
export class CharacterComponent {
  @Input() character;

  getProperties() {
    return [
      { label: 'Gender', value: this.character.gender },
      { label: 'Birth Year', value: this.character.birth_year },
      { label: 'Eye Color', value: this.character.eye_color },
      { label: 'Skin Color', value: this.character.skin_color },
    ];
  }
}