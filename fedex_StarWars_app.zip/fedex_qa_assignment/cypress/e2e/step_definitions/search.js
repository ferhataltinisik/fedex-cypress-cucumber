import {
    Given,
    When,
    Then,
  } from "@badeball/cypress-cucumber-preprocessor";
  import {searchPage} from '@pages/SearchPage.js'
  import { selectRadioButton, verifyCharacterCardInfo, verifyPlanetCardInfo } from '../../support/helper';

  Given("I am on the Star Wars search page", function () {
    cy.visit('/')
  
  });
  
  When('I select {string} radio button', (radioBtnValue) => {
    selectRadioButton(radioBtnValue);
  });
  
  
  When("I type {string} into the search box", (keyword) => {
    searchPage.typeSearchText(keyword)
  
  });
  
  When("I press on the search button", () => {
    searchPage.clickOnSearchButton();
  });
  
  Then('I should see the person name {string}, gender {string}, birth year {string}, eye color {string}, and skin color {string} of the character in the search results', (name, gender, birthYear, eyeColor, skinColor) => {
    searchPage.getCardTitle().should('contain', name);
    searchPage.getGenderValue().should('contain', gender);
    searchPage.getBirthYearValue().should('contain', birthYear);
    searchPage.getEyeColorValue().should('contain', eyeColor);
    searchPage.getSkincolorValue().should('contain', skinColor);
  });

  Then("I should see the planet name {string}, population {string}, climate {string}, gravity {string} of the planet in the search results", (name, population, climate, gravity) => {
    searchPage.getCardTitle().should('contain', name);
    searchPage.getPopulationValue().should('contain', population);
    searchPage.getClimateValue().should('contain', climate);
    searchPage.getGravityValue().should('contain', gravity);
  
  });

  Given("I trigger the Enter key event on the search input", () => {
    searchPage.enterKeyEventOnSearchInput();
  });
  

  Given("I should see more than one character information in search results", function () {
        // Extract data from search results
        searchPage.getCards().each((card) => {
          verifyCharacterCardInfo(card);
        })
      
        searchPage.getCards().then(($cards) => {
          const count = $cards.length;
          expect(count).to.be.greaterThan(1);
        });
    });

  Then('I should see more than one planet information in search results', () => {
    // Extract data from search results
    searchPage.getCards().each((card) => {
      verifyPlanetCardInfo(card);
    })
  
    searchPage.getCards().then(($cards) => {
      const count = $cards.length;
      expect(count).to.be.greaterThan(1);
    });
  })
  
  Then("I should see search input field is cleared after searching", (message) => {
    searchPage.elements.searchInputBox().should('have.value', '')
  });
  
  Given("I should see {string} in the search results", (message) => {
    searchPage.getNotFoundErrorMessage().should('contain', message);
  });