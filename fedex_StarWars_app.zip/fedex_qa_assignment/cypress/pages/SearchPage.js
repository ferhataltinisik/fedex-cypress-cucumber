class SearchPage {
    elements = {
        searchInputBox: () => cy.get('#query'),
        searchButton: () => cy.get('button:contains("Search")'),
        cardTitle: () => cy.get('#card-subtitle'),
        genderValue: () => cy.get('#gender-value'),
        birthYearValue: () => cy.get('#birth-year-value'),
        eyeColorValue: () => cy.get('#eye-color-value'),
        skinColorValue: () => cy.get('#skin-color-value'),
        populationValue: () => cy.get('#population-value'),
        climateValue: () => cy.get('#climate-value'),
        gravityValue: () =>  cy.get('#gravity-value'),
        cards: () => cy.get('.card-body').not(':first'),
        notFoundErrorMessage: () => cy.get('#notFound'),
  
      }
      
    
      typeSearchText(text) {
        //   this.elements.searchInputBox().should('not.be.disabled').type(text);
          cy.get('#query').should('not.be.disabled').type(text)

      }
  
      clickOnSearchButton() {
          this.elements.searchButton().click();
      }
  
      enterKeyEventOnSearchInput() {
          this.elements.searchInputBox().type('{enter}');
      }
  
  
      getCardTitle() {
          return this.elements.cardTitle();
      }
  
      getGenderValue() {
          return this.elements.genderValue();
      }
  
      getBirthYearValue() {
          return this.elements.birthYearValue();
      }
  
      getEyeColorValue() {
          return this.elements.eyeColorValue();
      }
  
      getSkincolorValue() {
          return this.elements.skinColorValue();
      }
  
      getPopulationValue() {
          return this.elements.populationValue();
      }
  
      getClimateValue() {
          return this.elements.climateValue();
      }
      
      getGravityValue() {
          return this.elements.gravityValue();
      }
  
      
      getCards(){
          return this.elements.cards();
      }
      
      getNotFoundErrorMessage(){
          return this.elements.notFoundErrorMessage();
      }
    
    }
  
  export const searchPage = new SearchPage();